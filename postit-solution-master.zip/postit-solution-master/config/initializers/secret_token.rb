# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
PostitTemplate::Application.config.secret_key_base = 'c3b33ac1dce53c248590d05387eaccc9ed3b370eea7f701dfb9e2e0ac6d1713b8eed49c97a19f1aab50bc96085700cf0834d77c53f42a1435670f8ff69440038'
